TOKEN = "5353848096:AAFe9-nKXhQJ41MhUXW48ZnboAZcG2blSgU"
with open('words.txt', 'r', encoding='utf-8') as file:
    word_list = file.read().splitlines()
